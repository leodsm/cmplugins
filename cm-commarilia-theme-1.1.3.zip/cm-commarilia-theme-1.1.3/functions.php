<?php
if (!defined('ABSPATH')) exit;

function cm_theme_setup(){
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
  register_nav_menus(array( 'primary'=>'Menu Principal' ));
  add_image_size('cm-card', 800, 1200, true);
}
add_action('after_setup_theme','cm_theme_setup');

function cm_theme_scripts(){
  wp_enqueue_style('cm-theme-style', get_stylesheet_uri(), array(), '1.1.3');
}
add_action('wp_enqueue_scripts','cm_theme_scripts');

$GLOBALS['content_width'] = 990;
