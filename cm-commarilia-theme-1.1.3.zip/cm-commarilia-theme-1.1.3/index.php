<?php get_header(); ?>
  <section class="cm-hero">
    <h2>Últimas Notícias</h2>
    <a class="button" href="<?php echo esc_url(get_permalink(get_option('page_for_posts'))); ?>">Todas</a>
  </section>

  <?php if ( function_exists('do_shortcode') ) echo do_shortcode('[cm_stories posts_per_page="9" cols="3" cols_tablet="2" cols_mobile="1" aspect_ratio="9/16"]'); ?>

  <hr/>
  <div class="posts-grid">
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
      <article id="post-<?php the_ID(); ?>" <?php post_class('post-card'); ?>>
        <a href="<?php the_permalink(); ?>" class="thumb"><?php if ( has_post_thumbnail() ) the_post_thumbnail('cm-card'); ?></a>
        <h3 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <div class="entry-meta"><?php echo get_the_date(); ?></div>
      </article>
    <?php endwhile; else: ?>
      <p>Sem posts ainda.</p>
    <?php endif; ?>
  </div>
<?php get_footer(); ?>
