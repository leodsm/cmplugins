<?php if (!defined('ABSPATH')) exit;
class CM_Stories_Admin {
  public function boot(){ add_action('admin_menu',[$this,'menu']); }
  public function menu(){ add_submenu_page('cm-studio','CM Stories – Configurações','Configurações','edit_posts','cm-stories',[$this,'render_settings_page']); }
  public function render_settings_page(){ echo '<div class="wrap"><h1>CM Stories – Configurações</h1><p>Use <strong>CM Studio → Estilo</strong> para aparência.</p></div>'; }
}
