<?php if (!defined('ABSPATH')) exit;
class CM_Stories_Studio {
  public function boot(){
    add_action('admin_menu',[$this,'menu']);
    add_action('admin_enqueue_scripts',[$this,'assets']);
    add_action('rest_api_init',[$this,'rest']);
    add_action('admin_init',[$this,'settings']);
  }
  public function menu(){
    add_menu_page('CM Studio','CM Studio','edit_posts','cm-studio',[$this,'render_studio'],'dashicons-layout',57);
    add_submenu_page('cm-studio','Estúdio','Estúdio','edit_posts','cm-studio',[$this,'render_studio']);
    add_submenu_page('cm-studio','Estilo','Estilo','manage_options','cm-studio-style',[$this,'render_style']);
    add_action('admin_head',function(){ if(!current_user_can('manage_options')) remove_submenu_page('cm-studio','edit.php?post_type=cm_story'); });
  }
  public function assets($hook){
    if (strpos($hook,'cm-studio')===false) return;
    wp_enqueue_style('bootstrap5','https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css',[],'5.3.3');
    wp_enqueue_script('bootstrap5','https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js',[],'5.3.3',true);
    wp_enqueue_media();
    wp_enqueue_style('cm-studio');
    wp_enqueue_script('cm-studio');
    wp_localize_script('cm-studio','CMSTUDIO',[ 'rest'=>esc_url_raw(rest_url()), 'nonce'=>wp_create_nonce('wp_rest') ]);
  }
  public function rest(){
    register_rest_route('cm-studio/v1','/publish/(?P<id>\d+)',[ 'methods'=>'POST','permission_callback'=>function(){return current_user_can('publish_posts');}, 'callback'=>function($r){ $id=(int)$r['id']; $res=wp_update_post(['ID'=>$id,'post_status'=>'publish'],true); if(is_wp_error($res)) return $res; return ['id'=>$id,'status'=>'publish']; } ]);
    register_rest_route('cm-studio/v1','/unpublish/(?P<id>\d+)',[ 'methods'=>'POST','permission_callback'=>function(){return current_user_can('edit_posts');}, 'callback'=>function($r){ $id=(int)$r['id']; $res=wp_update_post(['ID'=>$id,'post_status'=>'draft'],true); if(is_wp_error($res)) return $res; return ['id'=>$id,'status'=>'draft']; } ]);
  }
  public function settings(){ register_setting('cm_studio_style_group','cm_studio_style'); }
  public function render_studio(){ include CM_STORIES_DIR.'admin/views/studio.php'; }
  public function render_style(){ $o=get_option('cm_studio_style',[ 'max_width'=>'990','aspect'=>'9/16','cols'=>3,'cols_tablet'=>2,'cols_mobile'=>1,'gutter'=>12,'card_pad'=>12,'label_more'=>'Ver Mais' ]); $terms=get_terms(['taxonomy'=>'cm_category','hide_empty'=>false]); include CM_STORIES_DIR.'admin/views/style.php'; }
}
