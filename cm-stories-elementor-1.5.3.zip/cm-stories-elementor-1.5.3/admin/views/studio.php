
<div class="wrap cm-studio container-fluid">
  <h1 class="mb-3">CM Studio — Stories</h1>
  <div class="row g-3">
    <div class="col-12 col-lg-5">
      <div class="card shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
          <strong>Stories</strong>
          <button class="btn btn-sm btn-primary" id="cm-new"><span class="dashicons dashicons-plus"></span> Novo</button>
        </div>
        <div class="card-body">
          <div class="input-group mb-2">
            <input type="text" class="form-control" id="cm-search" placeholder="Buscar por título">
            <button class="btn btn-outline-secondary" id="cm-reload">Atualizar</button>
          </div>
          <div class="table-responsive">
            <table class="table align-middle">
              <thead><tr><th>Título</th><th>Status</th><th>Cat.</th><th>Atualizado</th><th></th></tr></thead>
              <tbody id="cm-list"></tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="col-12 col-lg-7">
      <div class="card shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
          <strong id="cm-form-title">Novo Story</strong>
          <small class="text-muted" id="cm-dirty-flag" style="display:none;">(alterações não salvas)</small>
        </div>
        <div class="card-body">
          <div class="mb-3">
            <label class="form-label">Título</label>
            <input type="text" id="cm-title" class="form-control" placeholder="Título do Story">
          </div>
          <div class="mb-3">
            <label class="form-label">Categoria</label>
            <select id="cm-term" class="form-select"></select>
          </div>
          <div class="mb-3">
            <label class="form-label d-flex justify-content-between">
              <span>Páginas</span><span>
                <button class="btn btn-sm btn-secondary" id="cm-add-page">+ Página</button>
              </span>
            </label>
            <ul class="list-group" id="cm-pages"></ul>
            <div class="form-text">Arraste para reordenar. Use “Capa” para definir a imagem destacada.</div>
          </div>
          <hr>
          <h5>Matéria completa</h5>
          <div class="mb-2"><input type="text" id="cm-full-title" class="form-control" placeholder="Título"></div>
          <div class="input-group mb-2">
            <input type="text" id="cm-full-image" class="form-control" placeholder="URL da imagem">
            <button class="btn btn-outline-secondary" id="cm-pick-full">Escolher</button>
          </div>
          <div class="mb-3"><textarea id="cm-full-body" class="form-control" rows="6" placeholder="HTML/Texto"></textarea></div>
        </div>
        <div class="card-footer d-flex gap-2">
          <button class="btn btn-secondary" id="cm-save-draft">Salvar rascunho</button>
          <button class="btn btn-primary" id="cm-save-publish">Publicar</button>
          <div class="ms-auto"><span id="cm-status" class="text-muted"></span></div>
        </div>
      </div>
    </div>
  </div>
</div>
