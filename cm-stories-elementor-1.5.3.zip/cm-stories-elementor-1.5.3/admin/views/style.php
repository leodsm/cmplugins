
<div class="wrap container-fluid">
  <h1>CM Studio — Estilo</h1>
  <form method="post" action="options.php">
    <?php settings_fields('cm_studio_style_group'); ?>
    <div class="row g-3">
      <div class="col-md-4">
        <label class="form-label">Largura máxima (px)</label>
        <input type="number" class="form-control" name="cm_studio_style[max_width]" value="<?php echo esc_attr($o['max_width']); ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Aspect Ratio</label>
        <select class="form-select" name="cm_studio_style[aspect]">
          <?php foreach(['1/1','4/3','3/2','16/9','3/4','2/3','9/16'] as $ar): ?>
            <option value="<?php echo esc_attr($ar);?>" <?php selected($o['aspect'],$ar); ?>><?php echo esc_html(str_replace('/',' : ',$ar));?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label">Label do botão (player)</label>
        <input type="text" class="form-control" name="cm_studio_style[label_more]" value="<?php echo esc_attr($o['label_more']); ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Colunas (Desktop)</label>
        <input type="number" class="form-control" name="cm_studio_style[cols]" value="<?php echo esc_attr($o['cols']); ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Colunas (Tablet)</label>
        <input type="number" class="form-control" name="cm_studio_style[cols_tablet]" value="<?php echo esc_attr($o['cols_tablet']); ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Colunas (Mobile)</label>
        <input type="number" class="form-control" name="cm_studio_style[cols_mobile]" value="<?php echo esc_attr($o['cols_mobile']); ?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">Gutter (px)</label>
        <input type="number" class="form-control" name="cm_studio_style[gutter]" value="<?php echo esc_attr($o['gutter']); ?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">Padding do card (px)</label>
        <input type="number" class="form-control" name="cm_studio_style[card_pad]" value="<?php echo esc_attr($o['card_pad']); ?>">
      </div>
      <div class="col-12">
        <label class="form-label">Categorias padrão</label><br/>
        <?php foreach($terms as $t): ?>
          <label class="me-3"><input type="checkbox" name="cm_studio_style[categories][]" value="<?php echo esc_attr($t->term_id); ?>" <?php if(!empty($o['categories']) && in_array($t->term_id,$o['categories'])) echo 'checked'; ?>> <?php echo esc_html($t->name); ?></label>
        <?php endforeach; ?>
      </div>
      <div class="col-12"><?php submit_button('Salvar estilo'); ?></div>
    </div>
  </form>
</div>
