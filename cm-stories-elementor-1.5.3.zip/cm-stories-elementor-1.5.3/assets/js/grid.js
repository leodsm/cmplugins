
(function($){
  function ensurePlayer(){
    if(!document.getElementById('cm-story-player')){
      $('body').append(
        '<div id="cm-story-player" class="cm-player hidden" data-label-more="Ver Mais">'+
          '<div class="cm-player-backdrop"></div>'+
          '<div class="cm-player-frame">'+
            '<div class="cm-swiper-vert"></div>'+
            '<button class="cm-player-close" aria-label="Fechar">&times;</button>'+
          '</div>'+
        '</div>'+
        '<div id="cm-story-modal" class="cm-modal hidden">'+
          '<div class="cm-modal-backdrop"></div>'+
          '<div class="cm-modal-sheet">'+
            '<button class="cm-modal-close" aria-label="Fechar">&times;</button>'+
            '<div class="cm-modal-content">'+
              '<h3 class="cm-modal-title"></h3>'+
              '<img class="cm-modal-image" alt=""/>'+
              '<div class="cm-modal-body"></div>'+
            '</div>'+
          '</div>'+
        '</div>'
      );
    }
  }
  function openFrom($card){
    ensurePlayer();
    const data = $card.data('story') || null;
    if(!data) return;
    const $player = $('#cm-story-player'), $wrap = $player.find('.cm-swiper-vert').empty();
    const pages = Array.isArray(data.pages) ? data.pages : [];
    (pages.length ? pages : (data.full && data.full.image ? [{title:data.title, mediaUrl:data.full.image}] : [])).forEach(p=>{
      const url = p.mediaUrl || ''; const title = p.title || '';
      $wrap.append('<div class="cm-slide"><img class="cm-slide-img" alt="'+title.replace(/\"/g,'&quot;')+'" src="'+url+'"/></div>');
    });
    if(data.full){
      $('#cm-story-modal .cm-modal-title').text(data.full.title||data.title||'');
      if(data.full.image) $('#cm-story-modal .cm-modal-image').attr('src',data.full.image).show(); else $('#cm-story-modal .cm-modal-image').hide();
      $('#cm-story-modal .cm-modal-body').html(data.full.body||'');
    }
    $player.removeClass('hidden'); $('body').addClass('cm-lock');
  }
  function closePlayer(){ $('#cm-story-player').addClass('hidden'); $('body').removeClass('cm-lock'); }
  function closeModal(){ $('#cm-story-modal').addClass('hidden'); }
  $(document).on('click','.cm-story-card', function(e){ e.preventDefault(); openFrom($(this)); });
  $(document).on('click','.cm-player-close,.cm-player-backdrop', closePlayer);
  $(document).on('click','.cm-modal-close,.cm-modal-backdrop', closeModal);
  $(document).on('keydown', function(e){ if(e.key==='Escape'){ closeModal(); closePlayer(); } });
})(jQuery);
