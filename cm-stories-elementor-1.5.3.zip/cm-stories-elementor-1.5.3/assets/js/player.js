
(function($){
  $(function(){
    const $player = $('#cm-story-player');
    if(!$player.length) return;
    const label = $player.data('label-more') || 'Ver Mais';
    if(!$player.find('.cm-more').length){
      $player.find('.cm-player-frame').append('<button class="cm-more">'+label+'</button>');
    }
    $(document).on('click','.cm-more', function(){ $('#cm-story-modal').removeClass('hidden'); });
    $(document).on('keydown', function(e){ if(e.key==='Escape'){ $('#cm-story-modal').addClass('hidden'); } });
  });
})(jQuery);
