
(function($){
  const API = {
    rest: (path,opt={})=> fetch((window.CMSTUDIO?CMSTUDIO.rest:'')+path, Object.assign({headers:{'Content-Type':'application/json','X-WP-Nonce': (window.CMSTUDIO?CMSTUDIO.nonce:'')}}, opt)),
    wp:   (path,opt={})=> fetch((window.CMSTUDIO?CMSTUDIO.rest:'')+'wp/v2/'+path, Object.assign({headers:{'Content-Type':'application/json','X-WP-Nonce': (window.CMSTUDIO?CMSTUDIO.nonce:'')}}, opt))
  };
  let current = null;
  let dirty = false, autosaveTimer = null;

  function setDirty(v){ dirty = v; $('#cm-dirty-flag').toggle(!!dirty); }
  function toast(msg, cls){ const el=$('<div class="notice '+(cls||'notice-success')+' is-dismissible"><p>'+msg+'</p></div>'); $('.wrap h1,.wrap .card-header').first().after(el); setTimeout(()=> el.fadeOut(300,()=>el.remove()), 2500); }
  function onFetch(r){ if(!r.ok) return r.json().then(j=>{ throw new Error((j&&(j.message||j.code))||'Erro'); }); return r.json(); }
  function pickImage(cb){ const frame=wp.media({title:'Escolher imagem', multiple:false, library:{type:'image'}}); frame.on('select',function(){ const f=frame.state().get('selection').first().toJSON(); cb({id:f.id,url:f.url,width:f.width,height:f.height}); }); frame.open(); }
  function scheduleAutosave(){ setDirty(true); if(autosaveTimer) clearTimeout(autosaveTimer); autosaveTimer=setTimeout(()=> save('draft', true), 1500); }

  function loadList(q){
    $('#cm-list').html('<tr><td colspan="5">Carregando...</td></tr>');
    let url='cm_story?per_page=20&orderby=modified&order=desc'; if(q) url+='&search='+encodeURIComponent(q);
    API.wp(url).then(onFetch).then(arr=>{
      const tb=$('#cm-list').empty(); if(!Array.isArray(arr)||arr.length===0){ tb.append('<tr><td colspan="5"><em>Sem stories</em></td></tr>'); return; }
      arr.forEach(s=>{
        const cats=(s.cm_category||[]).join(','), tr=$('<tr></tr>');
        tr.append('<td><a href="#" class="cm-edit" data-id="'+s.id+'">'+(s.title.rendered||'(sem título)')+'</a></td>');
        tr.append('<td>'+s.status+'</td>'); tr.append('<td>'+(cats||'-')+'</td>');
        tr.append('<td>'+(s.modified?new Date(s.modified).toLocaleString():'')+'</td>');
        tr.append('<td class="text-end"><button class="button button-small cm-pub" data-id="'+s.id+'">Publicar</button> <button class="button button-small cm-draft" data-id="'+s.id+'">Rascunho</button></td>');
        tb.append(tr);
      });
    }).catch(err=> toast('Erro: '+err.message,'notice-error'));
  }

  function loadTerms(){ API.wp('cm_category?per_page=100&hide_empty=false').then(onFetch).then(ts=>{ const s=$('#cm-term').empty(); s.append('<option value="">(sem categoria)</option>'); ts.forEach(t=> s.append('<option value="'+t.id+'">'+t.name+'</option>')); }).catch(err=> toast('Erro ao carregar categorias: '+err.message,'notice-error')); }

  function pageItem(p){
    const li=$('<li class="list-group-item d-flex align-items-center gap-2"></li>');
    const thumb=$('<img class="cm-p-thumb" alt="" style="width:56px;height:56px;object-fit:cover;border-radius:8px;background:#f3f3f3;">');
    if(p.mediaUrl) thumb.attr('src',p.mediaUrl);
    li.append('<span class="dashicons dashicons-move handle"></span>'); li.append(thumb);
    li.append('<input type="text" class="form-control form-control-sm cm-p-title" placeholder="Título" value="'+(p.title||'')+'">');
    const url=$('<input type="text" class="form-control form-control-sm cm-p-url" placeholder="URL da imagem" value="'+(p.mediaUrl||'')+'">'); li.append(url);
    const pick=$('<button class="btn btn-sm btn-outline-secondary cm-p-pick">Escolher</button>');
    const cover=$('<button class="btn btn-sm btn-outline-primary cm-p-cover">Capa</button>');
    const del=$('<button class="btn btn-sm btn-outline-danger cm-p-del">Remover</button>'); li.append(pick,cover,del);
    if(p.mediaId) li.data('mediaId',p.mediaId);
    li.on('click','.cm-p-pick', function(){ pickImage(f=>{ url.val(f.url).trigger('input'); li.data('mediaId',f.id); thumb.attr('src',f.url); scheduleAutosave(); }); });
    li.on('click','.cm-p-cover', function(){
      if(!current||!current.id){ toast('Abra/salve o Story antes','notice-error'); return; }
      const id=li.data('mediaId'); const img=url.val(); if(!id){ toast('Escolha a imagem pela Biblioteca para definir a capa','notice-error'); return; }
      API.wp('cm_story/'+current.id,{method:'POST', body: JSON.stringify({ featured_media:id, meta:{ full_content_image: img } })}).then(onFetch).then(()=> toast('Capa definida')).catch(err=> toast('Erro ao definir capa: '+err.message,'notice-error'));
    });
    li.on('click','.cm-p-del', function(){ li.remove(); scheduleAutosave(); });
    url.on('input', function(){ thumb.attr('src', this.value); scheduleAutosave(); });
    li.find('.cm-p-title').on('input', scheduleAutosave);
    return li;
  }
  function addPage(p){ $('#cm-pages').append(pageItem(p||{title:'',mediaUrl:''})); }

  function fillForm(s){
    current={ id:s.id, title:s.title?.rendered||'', pages:(s.meta&&s.meta.pages)||[], full:{ title:s.meta?.full_content_title||'', image:s.meta?.full_content_image||'', body:s.meta?.full_content_body||'' }, terms:(s.cm_category||[]) };
    $('#cm-form-title').text(current.id?('Editar Story #'+current.id):'Novo Story');
    $('#cm-title').val(current.title); $('#cm-full-title').val(current.full.title); $('#cm-full-image').val(current.full.image); $('#cm-full-body').val(current.full.body); $('#cm-term').val(current.terms[0]||'');
    $('#cm-pages').empty(); (current.pages||[]).forEach(addPage); setDirty(false);
  }

  function createNew(){ API.wp('cm_story',{method:'POST', body: JSON.stringify({title:'Novo Story', status:'draft'})}).then(onFetch).then(s=>{ loadList(); openEditor(s.id); toast('Story criado'); }).catch(err=> toast('Erro ao criar: '+err.message,'notice-error')); }
  function openEditor(id){ API.wp('cm_story/'+id).then(onFetch).then(fillForm).catch(err=> toast('Erro ao abrir: '+err.message,'notice-error')); }
  function collectPages(){ const pages=[]; $('#cm-pages .list-group-item').each(function(){ pages.push({ title: $(this).find('.cm-p-title').val(), mediaUrl: $(this).find('.cm-p-url').val() }); }); return pages; }

  function save(status, silent){
    if(!current||!current.id){ toast('Nenhum story selecionado','notice-error'); return Promise.resolve(); }
    const term=$('#cm-term').val();
    const body={ title: $('#cm-title').val()||'Story', status: status||'draft', meta:{ pages: collectPages(), full_content_title: $('#cm-full-title').val(), full_content_image: $('#cm-full-image').val(), full_content_body: $('#cm-full-body').val() } };
    if(term){ body.cm_category=[parseInt(term,10)]; body.tax_input={ cm_category:[parseInt(term,10)] }; }
    return API.wp('cm_story/'+current.id,{ method:'POST', body: JSON.stringify(body) }).then(onFetch).then(s=>{ fillForm(s); loadList($('#cm-search').val()); if(!silent) toast('Salvo'); setDirty(false); }).catch(err=> toast('Erro ao salvar: '+err.message,'notice-error'));
  }

  $(function(){
    loadTerms(); loadList();
    $('#cm-reload').on('click', ()=> loadList($('#cm-search').val()) );
    $('#cm-search').on('keyup', function(e){ if(e.key==='Enter') loadList(this.value); });
    $('#cm-new').on('click', createNew);
    $('#cm-add-page').on('click', ()=> { addPage({title:'',mediaUrl:''}); scheduleAutosave(); } );
    $('#cm-pick-full').on('click', ()=> pickImage(f=> { $('#cm-full-image').val(f.url).trigger('input'); scheduleAutosave(); }) );
    $('#cm-save-draft').on('click', ()=> save('draft') );
    $('#cm-save-publish').on('click', ()=> save('publish').then(()=>{ if(current&&current.id) return API.rest('cm-studio/v1/publish/'+current.id,{method:'POST'}); }).then(()=> toast('Publicado')).catch(()=>{}) );
    $('#cm-pages').sortable({ handle: '.handle', update: scheduleAutosave });

    $(document).on('input change', '#cm-title,#cm-term,#cm-full-title,#cm-full-image,#cm-full-body', scheduleAutosave);
    $(document).on('click','.cm-edit', function(e){ e.preventDefault(); openEditor($(this).data('id')); });
    $(document).on('click','.cm-pub', function(){ const id=$(this).data('id'); API.rest('cm-studio/v1/publish/'+id,{method:'POST'}).then(onFetch).then(()=>{ loadList($('#cm-search').val()); toast('Publicado'); }).catch(err=> toast('Erro: '+err.message,'notice-error')); });
    $(document).on('click','.cm-draft', function(){ const id=$(this).data('id'); API.rest('cm-studio/v1/unpublish/'+id,{method:'POST'}).then(onFetch).then(()=>{ loadList($('#cm-search').val()); toast('Rascunho'); }).catch(err=> toast('Erro: '+err.message,'notice-error')); });

    window.addEventListener('beforeunload', function(e){ if(!dirty) return; e.preventDefault(); e.returnValue=''; });
  });
})(jQuery);
