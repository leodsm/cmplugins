<?php
/**
 * Plugin Name: CM Stories (Studio + Grid + Player)
 * Description: Stories com Grid, Player e CM Studio (cria\u00e7\u00e3o/edi\u00e7\u00e3o/publica\u00e7\u00e3o). Widget \u00fanico para Elementor.
 * Version: 1.5.3
 * Author: CM Suite
 * Text Domain: cm-stories
 */
if (!defined('ABSPATH')) exit;
define('CM_STORIES_VERSION','1.5.3');
define('CM_STORIES_DIR', plugin_dir_path(__FILE__));
define('CM_STORIES_URL', plugin_dir_url(__FILE__));
require_once CM_STORIES_DIR.'includes/class-plugin.php';
add_action('plugins_loaded', function(){ (new CM_Stories_Plugin())->boot(); });
