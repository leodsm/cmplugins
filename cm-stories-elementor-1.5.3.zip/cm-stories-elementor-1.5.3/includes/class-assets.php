<?php if (!defined('ABSPATH')) exit;
class CM_Stories_Assets {
  public function register(){
    add_action('init', function(){
      wp_register_style('cm-stories-frontend', CM_STORIES_URL.'assets/css/frontend.css', [], CM_STORIES_VERSION);
      wp_register_script('cm-stories-grid', CM_STORIES_URL.'assets/js/grid.js', ['jquery'], CM_STORIES_VERSION, true);
      wp_register_script('cm-stories-player', CM_STORIES_URL.'assets/js/player.js', ['jquery'], CM_STORIES_VERSION, true);
      if (is_admin()){
        wp_register_style('cm-studio', CM_STORIES_URL.'assets/css/studio.css', [], CM_STORIES_VERSION);
        wp_register_script('cm-studio', CM_STORIES_URL.'assets/js/studio-bootstrap.js', ['jquery','jquery-ui-sortable'], CM_STORIES_VERSION, true);
      }
    });
  }
}
