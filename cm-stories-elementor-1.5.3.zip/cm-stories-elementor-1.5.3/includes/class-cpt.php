<?php if (!defined('ABSPATH')) exit;
class CM_Stories_CPT {
  public function register(){
    add_action('init', function(){
      register_post_type('cm_story',[
        'label'=>'Stories',
        'labels'=>[ 'name'=>'Stories','singular_name'=>'Story' ],
        'public'=>true,
        'show_in_rest'=>true,
        'show_in_menu'=>'cm-studio',
        'menu_icon'=>'dashicons-format-gallery',
        'supports'=>['title','editor','thumbnail'],
        'has_archive'=>false,
        'rewrite'=>['slug'=>'cm-story'],
      ]);
    });
  }
}
