<?php if (!defined('ABSPATH')) exit;
class CM_Stories_Elementor_Loader {
  public function boot(){ add_action('elementor/widgets/register',[$this,'register']); }
  public function register($wm){
    require_once CM_STORIES_DIR.'includes/widgets/class-widget-stories.php';
    $wm->register(new CM_Stories_Widget_Stories());
  }
}
