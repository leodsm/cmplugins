<?php if (!defined('ABSPATH')) exit;
class CM_Stories_Meta {
  public function register(){ add_action('init',[$this,'do']); }
  public function do(){
    $sanitize_pages = function($v){ if(!is_array($v)) return []; $out=[];
      foreach($v as $i){ $out[]=['title'=>isset($i['title'])?sanitize_text_field($i['title']):'','mediaUrl'=>isset($i['mediaUrl'])?esc_url_raw($i['mediaUrl']):'']; }
      return $out;
    };
    register_post_meta('cm_story','pages',[ 'type'=>'array','single'=>true,
      'show_in_rest'=>[ 'schema'=>['type'=>'array','items'=>['type'=>'object','properties'=>['title'=>['type'=>'string'],'mediaUrl'=>['type'=>'string','format'=>'uri']], 'additionalProperties'=>false]]],
      'auth_callback'=>function(){return current_user_can('edit_posts');},
      'sanitize_callback'=>$sanitize_pages
    ]);
    register_post_meta('cm_story','full_content_title',[ 'type'=>'string','single'=>true,'show_in_rest'=>true,'auth_callback'=>function(){return current_user_can('edit_posts');},'sanitize_callback'=>'sanitize_text_field' ]);
    register_post_meta('cm_story','full_content_image',[ 'type'=>'string','single'=>true,'show_in_rest'=>true,'auth_callback'=>function(){return current_user_can('edit_posts');},'sanitize_callback'=>'esc_url_raw' ]);
    register_post_meta('cm_story','full_content_body',[ 'type'=>'string','single'=>true,'show_in_rest'=>true,'auth_callback'=>function(){return current_user_can('edit_posts');},'sanitize_callback'=>function($v){return wp_kses_post($v);} ]);
  }
}
