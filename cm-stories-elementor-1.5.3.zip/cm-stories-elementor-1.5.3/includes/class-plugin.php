<?php if (!defined('ABSPATH')) exit;
class CM_Stories_Plugin {
  public function boot(){
    require_once CM_STORIES_DIR.'includes/class-assets.php';
    require_once CM_STORIES_DIR.'includes/class-cpt.php';
    require_once CM_STORIES_DIR.'includes/class-taxonomy.php';
    require_once CM_STORIES_DIR.'includes/class-meta.php';
    require_once CM_STORIES_DIR.'includes/class-shortcodes.php';
    require_once CM_STORIES_DIR.'includes/class-elementor-loader.php';
    require_once CM_STORIES_DIR.'admin/class-admin.php';
    require_once CM_STORIES_DIR.'admin/class-studio.php';
    (new CM_Stories_Assets())->register();
    (new CM_Stories_CPT())->register();
    (new CM_Stories_Taxonomy())->register();
    (new CM_Stories_Meta())->register();
    (new CM_Stories_Shortcodes())->register();
    (new CM_Stories_Admin())->boot();
    (new CM_Stories_Studio())->boot();
    (new CM_Stories_Elementor_Loader())->boot();
  }
}
