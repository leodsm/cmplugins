<?php if (!defined('ABSPATH')) exit;
class CM_Stories_Shortcodes {
  public function register(){
    add_shortcode('cm_stories',[$this,'grid']);
    add_shortcode('cm_story_player',[$this,'player']);
  }
  public function grid($atts){
    $defaults = get_option('cm_studio_style', []);
    $atts = shortcode_atts([
      'posts_per_page'=>9,
      'aspect_ratio'=>$defaults['aspect']??'9/16',
      'cols'=>$defaults['cols']??3,
      'cols_tablet'=>$defaults['cols_tablet']??2,
      'cols_mobile'=>$defaults['cols_mobile']??1,
      'gutter'=>$defaults['gutter']??12,
      'card_pad'=>$defaults['card_pad']??12,
      'label_more'=>$defaults['label_more']??'Ver Mais',
      'categories'=>''
    ], $atts,'cm_stories');
    wp_enqueue_style('cm-stories-frontend');
    wp_enqueue_script('cm-stories-grid');
    wp_enqueue_script('cm-stories-player');

    $tax=[];
    if(!empty($atts['categories'])){ $ids=array_map('intval',explode(',',$atts['categories'])); $tax=[[ 'taxonomy'=>'cm_category','field'=>'term_id','terms'=>$ids ]]; }
    $q=new WP_Query([ 'post_type'=>'cm_story','posts_per_page'=>intval($atts['posts_per_page']),'tax_query'=>$tax ]);

    ob_start(); ?>
    <div class="cm-stories-grid" style="--cm-card-ratio: <?php echo esc_attr($atts['aspect_ratio']); ?>; --cm-grid-cols: <?php echo intval($atts['cols']); ?>; --cm-grid-cols-md: <?php echo intval($atts['cols_tablet']); ?>; --cm-grid-cols-sm: <?php echo intval($atts['cols_mobile']); ?>; --cm-grid-gap: <?php echo intval($atts['gutter']); ?>px; --cm-card-pad: <?php echo intval($atts['card_pad']); ?>px;">
      <?php while($q->have_posts()): $q->the_post(); $pid=get_the_ID();
          $terms=get_the_terms($pid,'cm_category');
          $cat=$terms&&!is_wp_error($terms)?$terms[0]->name:'';
          $color=$terms&&!is_wp_error($terms)?get_term_meta($terms[0]->term_id,'cm_category_color',true):'#0ea5e9';
          $data=[
            'id'=>$pid,'title'=>get_the_title(),'category'=>$cat,'categoryColor'=>$color?:'#0ea5e9',
            'pages'=>get_post_meta($pid,'pages',true)?:[],
            'full'=>[ 'title'=>get_post_meta($pid,'full_content_title',true)?:get_the_title(), 'image'=>get_post_thumbnail_id($pid)?get_the_post_thumbnail_url($pid,'large'):'', 'body'=>wp_kses_post(get_post_meta($pid,'full_content_body',true)?:get_the_content()) ]
          ];
          $json=esc_attr(wp_json_encode($data)); $thumb=get_the_post_thumbnail_url($pid,'large'); ?>
          <article class="cm-story-card" data-story='<?php echo $json; ?>'>
             <div class="cm-card-media" style="background-image:url('<?php echo esc_url($thumb); ?>')"></div>
             <div class="cm-card-overlay"></div>
             <div class="cm-card-meta"><?php if($cat): ?><span class="cm-pill" style="--cm-pill: <?php echo esc_attr($color?:'#0ea5e9'); ?>;"><?php echo esc_html($cat); ?></span><?php endif; ?><h3 class="cm-card-title"><?php the_title(); ?></h3></div>
          </article>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
    <?php echo $this->player(['label_more'=>$atts['label_more']], false); ?>
    <?php return ob_get_clean();
  }
  public function player($atts=[],$echo=true){
    $atts=shortcode_atts(['label_more'=>'Ver Mais'],$atts,'cm_story_player');
    wp_enqueue_style('cm-stories-frontend'); wp_enqueue_script('cm-stories-player');
    ob_start(); ?>
    <div id="cm-story-player" class="cm-player hidden" data-label-more="<?php echo esc_attr($atts['label_more']); ?>">
      <div class="cm-player-backdrop"></div>
      <div class="cm-player-frame"><div class="cm-swiper-vert"></div><button class="cm-player-close" aria-label="Fechar">&times;</button></div>
    </div>
    <div id="cm-story-modal" class="cm-modal hidden">
      <div class="cm-modal-backdrop"></div>
      <div class="cm-modal-sheet">
        <button class="cm-modal-close" aria-label="Fechar">&times;</button>
        <div class="cm-modal-content"><h3 class="cm-modal-title"></h3><img class="cm-modal-image" alt=""/><div class="cm-modal-body"></div></div>
      </div>
    </div>
    <?php $out=ob_get_clean(); if($echo) echo $out; return $out;
  }
}
