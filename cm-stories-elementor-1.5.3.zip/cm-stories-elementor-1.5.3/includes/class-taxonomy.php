<?php if (!defined('ABSPATH')) exit;
class CM_Stories_Taxonomy {
  public function register(){
    add_action('init', function(){
      register_taxonomy('cm_category','cm_story',[
        'label'=>'Categorias (Stories)',
        'public'=>true, 'hierarchical'=>false, 'show_in_rest'=>true,
        'rewrite'=>['slug'=>'cm-category']
      ]);
    });
    add_action('cm_category_add_form_fields',[$this,'add_color_field']);
    add_action('cm_category_edit_form_fields',[$this,'edit_color_field']);
    add_action('created_cm_category',[$this,'save_color']);
    add_action('edited_cm_category',[$this,'save_color']);
    register_term_meta('cm_category','cm_category_color',[
      'type'=>'string','single'=>true,'show_in_rest'=>true,
      'sanitize_callback'=>'sanitize_hex_color','auth_callback'=>'__return_true'
    ]);
  }
  public function add_color_field(){ ?>
    <div class="form-field"><label for="cm_category_color">Cor (HEX)</label>
      <input type="text" id="cm_category_color" name="cm_category_color" value="#0ea5e9"></div><?php
  }
  public function edit_color_field($term){ $c=get_term_meta($term->term_id,'cm_category_color',true); ?>
    <tr class="form-field"><th><label for="cm_category_color">Cor (HEX)</label></th>
      <td><input type="text" id="cm_category_color" name="cm_category_color" value="<?php echo esc_attr($c?:'#0ea5e9'); ?>"></td></tr><?php
  }
  public function save_color($id){ if(isset($_POST['cm_category_color'])) update_term_meta($id,'cm_category_color',sanitize_hex_color($_POST['cm_category_color'])?:'#0ea5e9'); }
}
