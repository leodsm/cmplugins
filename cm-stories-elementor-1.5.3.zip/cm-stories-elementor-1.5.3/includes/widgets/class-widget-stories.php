<?php if (!defined('ABSPATH')) exit;
use Elementor\Controls_Manager; use Elementor\Widget_Base;
class CM_Stories_Widget_Stories extends Widget_Base {
  public function get_name(){ return 'cm-stories'; }
  public function get_title(){ return 'CM Stories (Grid + Player)'; }
  public function get_icon(){ return 'eicon-gallery-grid'; }
  public function get_categories(){ return ['general']; }
  public function get_script_depends(){ return ['cm-stories-grid','cm-stories-player']; }
  public function get_style_depends(){ return ['cm-stories-frontend']; }
  protected function register_controls(){
    $this->start_controls_section('content',['label'=>'Conteúdo']);
    $this->add_control('posts_per_page',['label'=>'Total de posts','type'=>Controls_Manager::NUMBER,'default'=>9,'min'=>1,'max'=>48]);
    $this->add_control('categories',['label'=>'Categorias (IDs, vírgula)','type'=>Controls_Manager::TEXT]);
    $this->end_controls_section();
    $this->start_controls_section('layout',['label'=>'Layout']);
    $this->add_control('aspect_ratio',['label'=>'Aspect Ratio','type'=>Controls_Manager::SELECT,'default'=>'9/16','options'=>['1/1'=>'1:1','4/3'=>'4:3','3/2'=>'3:2','16/9'=>'16:9','3/4'=>'3:4','2/3'=>'2:3','9/16'=>'9:16']]);
    $this->add_responsive_control('columns',['label'=>'Colunas','type'=>Controls_Manager::NUMBER,'min'=>1,'max'=>6,'default'=>3,'tablet_default'=>2,'mobile_default'=>1]);
    $this->add_control('gutter',['label'=>'Gutter (px)','type'=>Controls_Manager::NUMBER,'default'=>12]);
    $this->add_control('card_pad',['label'=>'Padding do card (px)','type'=>Controls_Manager::NUMBER,'default'=>12]);
    $this->add_control('label_more',['label'=>'Label do botão (player)','type'=>Controls_Manager::TEXT,'default'=>'Ver Mais']);
    $this->end_controls_section();
  }
  protected function render(){
    $s=$this->get_settings_for_display();
    echo do_shortcode('[cm_stories posts_per_page="'.$s['posts_per_page'].'" categories="'.$s['categories'].'" aspect_ratio="'.$s['aspect_ratio'].'" cols="'.$s['columns'].'" cols_tablet="'.$s['columns_tablet'].'" cols_mobile="'.$s['columns_mobile'].'" gutter="'.$s['gutter'].'" card_pad="'.$s['card_pad'].'" label_more="'.$s['label_more'].'"]');
  }
}
